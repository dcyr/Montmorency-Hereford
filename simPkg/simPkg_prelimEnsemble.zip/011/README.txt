simID 011
areaName Hereford
scenario RCP85
mgmt 4
spinup FALSE
replicate 1
