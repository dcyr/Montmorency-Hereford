simID 033
areaName ForMont
scenario baseline
mgmt 3.3
spinup FALSE
replicate 1
