simID 001
areaName Hereford
scenario RCP45
mgmt 1
spinup FALSE
replicate 1
