simID 036
areaName ForMont
scenario baseline
mgmt 4.1
spinup FALSE
replicate 1
