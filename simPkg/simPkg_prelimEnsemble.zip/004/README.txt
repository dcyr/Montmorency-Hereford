simID 004
areaName Hereford
scenario RCP45
mgmt 2
spinup FALSE
replicate 1
