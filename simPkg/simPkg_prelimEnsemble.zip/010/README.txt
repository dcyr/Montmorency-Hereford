simID 010
areaName Hereford
scenario RCP45
mgmt 4
spinup FALSE
replicate 1
