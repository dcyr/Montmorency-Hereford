simID 020
areaName ForMont
scenario RCP85
mgmt 2.1
spinup FALSE
replicate 1
