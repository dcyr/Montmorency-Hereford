simID 002
areaName Hereford
scenario RCP85
mgmt 1
spinup FALSE
replicate 1
