simID 039
areaName ForMont
scenario baseline
mgmt 4.2
spinup FALSE
replicate 1
