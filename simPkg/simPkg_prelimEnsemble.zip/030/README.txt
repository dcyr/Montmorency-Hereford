simID 030
areaName ForMont
scenario baseline
mgmt 3.2
spinup FALSE
replicate 1
