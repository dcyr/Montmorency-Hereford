simID 027
areaName ForMont
scenario baseline
mgmt 3.1
spinup FALSE
replicate 1
