simID 009
areaName Hereford
scenario baseline
mgmt 4
spinup FALSE
replicate 1
