simID 003
areaName Hereford
scenario baseline
mgmt 2
spinup FALSE
replicate 1
