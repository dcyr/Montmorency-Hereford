simID 005
areaName Hereford
scenario RCP85
mgmt 2
spinup FALSE
replicate 1
