simID 018
areaName ForMont
scenario baseline
mgmt 2.1
spinup FALSE
replicate 1
