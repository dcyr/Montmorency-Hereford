simID 015
areaName ForMont
scenario baseline
mgmt 1
spinup FALSE
replicate 1
