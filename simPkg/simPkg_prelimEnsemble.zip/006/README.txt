simID 006
areaName Hereford
scenario baseline
mgmt 3
spinup FALSE
replicate 1
