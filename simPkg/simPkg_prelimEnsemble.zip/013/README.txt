simID 013
areaName ForMont
scenario RCP45
mgmt 0
spinup FALSE
replicate 1
