simID 012
areaName ForMont
scenario baseline
mgmt 0
spinup FALSE
replicate 1
