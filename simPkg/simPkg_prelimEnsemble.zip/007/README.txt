simID 007
areaName Hereford
scenario RCP45
mgmt 3
spinup FALSE
replicate 1
