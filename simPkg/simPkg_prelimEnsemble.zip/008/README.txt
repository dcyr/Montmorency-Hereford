simID 008
areaName Hereford
scenario RCP85
mgmt 3
spinup FALSE
replicate 1
