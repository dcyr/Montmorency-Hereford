simID 024
areaName ForMont
scenario baseline
mgmt 2.3
spinup FALSE
replicate 1
